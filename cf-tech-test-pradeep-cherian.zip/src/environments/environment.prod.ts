export const environment = {
  production: true,
  MOCK_API_ENDPOINT:  'https://jsonplaceholder.typicode.com/',
  USER_ID: 2,
};
